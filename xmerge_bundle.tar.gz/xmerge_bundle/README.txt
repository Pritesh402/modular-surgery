x-merge pipeline bundle
=======================
deps: stim 1.16.0, numpy 2.2.6, pymatching 2.4.0

RUN:
    PY=python3 ./run_pipeline.sh x-merge-bell-d7_3obs_annotated.stim

Stages: diagnose -> graphlike_basis -> elementary_basis -> diagnose
        -> logical_detector_fix -> diagnose.
Outputs + logs land in logs/x-merge-bell-d7_3obs/.  Stages whose output already
exists are skipped, so an OOM-kill or Ctrl-C resumes instead of restarting.

SEND BACK: logs/x-merge-bell-d7_3obs/*.log

READING xmerge_diagnose.py OUTPUT -- three numbers decide everything:
  DEPENDENCIES  0 = healthy.  >0 = observable-coset detectors present AND the
                reported distance is inflated (d5 read 5, truth was 4).
  NON-GRAPHLIKE 0 = MWPM-ready.
  outlier cov   100% = logical_detector_fix.py can fix it.  <100% = ordinary
                basis artifacts remain.

FOR d9, once the annotated circuit exists:
    python add_seam_observables.py x-merge-bell-d9_annotated.stim -o x-merge-bell-d9_3obs_annotated.stim
    PY=python3 ./run_pipeline.sh x-merge-bell-d9_3obs_annotated.stim

NOTE: graphlike_basis.py here is PATCHED -- the original kept only the LAST
OBSERVABLE_INCLUDE, silently destroying L0 and L1 of a 3-observable circuit.
